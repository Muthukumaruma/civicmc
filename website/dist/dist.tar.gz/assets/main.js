
$(document).ready(function(){
	$(".main_menu ul li a").click(function(){
		$(".navbar-toggle").trigger("click")
	})
})
